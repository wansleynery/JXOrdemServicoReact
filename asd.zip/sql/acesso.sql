SELECT
    ad_controleos AS acesso
    
FROM
    tsiusu
    
WHERE
    codusu = %id