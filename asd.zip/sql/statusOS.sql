select
    codcos as \"value\",
    codcos || '. ' || descricao as \"label\"
    
from tcscos